public interface ICartItem
{
    // Retrieves the core data associated with a cart item
    CollectibleItem GetItemData();
}
