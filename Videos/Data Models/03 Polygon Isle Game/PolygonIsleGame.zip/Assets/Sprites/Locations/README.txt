Since the background image sprites from the project video aren't distributable, you'll need to recreate the screenshots yourself. The asset pack is linked below. In the video, I used a bird's-eye view of the map with location markers. To replicate this, simply use the demo level provided in the package, go to the specified spot, and grab screenshots in all cardinal directions. Then, apply them to the project's scriptable object locations. Just a heads-up: I used the Unreal asset pack, so I'm not sure if the Unity version includes the demo level.

RPG Tiny Fantasy Forest

Unity Version
https://assetstore.unity.com/packages/3d/environments/fantasy/rpg-tiny-fantasy-forest-pbr-309458

Unreal Version
https://www.fab.com/listings/ab68899a-db42-4b1b-8c0f-989540e2a42a